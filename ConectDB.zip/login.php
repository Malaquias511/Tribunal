<?php

require 'ConectDB/index.php';

$username = $_POST['email'];
$password = $_POST['password'];




if($username !="" && $password !=""){


$SearchUser=$Connection->prepare("SELECT * FROM Usuarios WHERE Email=? and Senha=?");
$SearchUser->bindParam(1,$username);
$SearchUser->bindParam(2,$password);
$SearchUser->execute();


if($SearchUser->rowCount() >=1){

while ($carregar = $SearchUser->fetch(PDO::FETCH_OBJ)) {

    if($username == $carregar->Email and $password == $carregar->Senha){

            session_start();
            $_SESSION['Nome'] = $carregar->Nome;
            $_SESSION['Tipo'] = $carregar->Tipo;
            $_SESSION['Apelido'] = $carregar->Apelido;
            $_SESSION['Email'] = $carregar->Email;
            $_SESSION['ID_USER'] = $carregar->ID_Usuarios ;

            


            if($carregar->Tipo != ''){

                $Resposta[] =array(
        
                'Titulo'=>'Acesso Liberado!',
                'Mensagem'=>'',
                'Type'=>'success',
                'CodeStatos'=>1
                
                
                );

                echo json_encode($Resposta);

            }
    }else{


      $Resposta[] =array(
        
                'Titulo'=>'Acesso Negado!',
                'Mensagem'=>'Dados Informados não correspodem',
                'Type'=>'error',
                'CodeStatos'=>0
                
                
                );

      echo json_encode($Resposta);
    


    }
}

}else{


       $Resposta[] =array(
        
                'Titulo'=>'Acesso Negado!',
                'Mensagem'=>'Dados Informados não correspodem',
                'Type'=>'error',
                'CodeStatos'=>0
                
                
                );
       echo json_encode($Resposta);
    

}




}



?>