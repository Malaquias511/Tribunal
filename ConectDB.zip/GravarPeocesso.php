<?php
require 'ConectDB/index.php';


$Numero = abs( crc32( uniqid() ) ); 
$ID_Seccao = $_POST["Seccao"];
$data = date('d-M-Y');
$dia = date('d');
$mes = date('m');
$ano = date('Y');
$CriadoPor = $_POST["ID"];


//INSERT INTO processos(Numero, Quixoso, Culposo, DadosProcesso, ID_Seccao, Codigo) VALUES (?,?,?,?,?,?)

if($ID_Seccao !=""){

$DadosProcesso = array("Origem"=>$_POST["OrigemProcess"], "Tipo"=>$_POST["TipoProcesso"]);
$DadosProcessoEncode = json_encode($DadosProcesso);

$Culposo = array("Nome"=>$_POST["NomeCulposos"], "Email"=>$_POST["EmailCulposo"], "Telefone"=>$_POST["TelefoneCulposo"], "Tipo_De_Documento"=>$_POST["TipoDocumentoCulposos"],"Numero_Do_Documento"=>$_POST["NumeroDocumentoCulposos"], "Local_De_Emissao"=>$_POST["LocalDeEmissaoCulposo"], "Endereco"=>$_POST["EnderecoCulposos"]);
$CulposoEncode = json_encode($Culposo);



$Quixoso = array("Nome"=>$_POST["NomeQueixoso"], "Email"=>$_POST["EmailQueixoso"], "Telefone"=>$_POST["TelefoneQueixoso"], "Tipo_De_Documento"=>$_POST["TipoDocumentoIdentificacaoQueixoso"],"Numero_Do_Documento"=>$_POST["NumeroDocumentoQueixoso"], "Local_De_Emissao"=>$_POST["LocalDeEmissaoDocumentoQueixoso"], "Endereco"=>$_POST["EnredecoQueixoso"]);
$QuixosoEncode = json_encode($Quixoso);

$Inserir = $Connection->prepare("INSERT INTO processos(Numero, Quixoso, Culposo, DadosProcesso, ID_Seccao, CriadoPor, Data_Criacao, Dia_Criacao, Mes_Criacao, Ano_Criacao) VALUES (?,?,?,?,?,?,?,?,?,?)");
$Inserir->bindParam(1, $Numero);
$Inserir->bindParam(2, $QuixosoEncode);
$Inserir->bindParam(3, $CulposoEncode);
$Inserir->bindParam(4, $DadosProcessoEncode);
$Inserir->bindParam(5, $ID_Seccao);
$Inserir->bindParam(6, $CriadoPor);
$Inserir->bindParam(7, $data);
$Inserir->bindParam(8, $dia);
$Inserir->bindParam(9, $mes);
$Inserir->bindParam(10, $ano);



if($Inserir->execute()){

	$Resposta[] =array(
        
                'Titulo'=>'Sucesso!',
                'Mensagem'=>'Processo Registado',
                'Type'=>'success',
                'CodeStatos'=>1
                
                
                );

                echo json_encode($Resposta);

}else{

	$Resposta[] =array(
        
                'Titulo'=>'Erro!',
                'Mensagem'=>'Ocorreu um erro ao registar Processo',
                'Type'=>'error',
                'CodeStatos'=>0
                
                
                );

      echo json_encode($Resposta);

}
}else{

	$Resposta[] =array(
        
                'Titulo'=>'Erro!',
                'Mensagem'=>'Selecione Pelomenos uma Secção',
                'Type'=>'error',
                'CodeStatos'=>0
                
                
                );

      echo json_encode($Resposta);


}
?>