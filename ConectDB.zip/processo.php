<?php

require 'ConectDB/index.php';
session_start();

if(isset($_SESSION['Tipo'])){
$Page = "Dashboard";  
$PageL2 = "";  



?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Invoice | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
    <?php require 'menu.php'?>

		<div class="main">
			<?php require 'header.php'?>;

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Processo</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body m-sm-3 m-md-5">
									<div class="mb-4">
										Fucionario <strong>Stelio Malaquias</strong>,
										<br />Origem. <strong>12a Esquadra Matola</strong>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="text-muted">Processo No.</div>
											<strong>741037024</strong>
										</div>
										<div class="col-md-6 text-md-end">
											<div class="text-muted">Data de criacao</div>
											<strong>October 2, 2021 - 03:45 pm</strong>
										</div>
									</div>

									<hr class="my-4" />

									<div class="row mb-4">
										<div class="col-md-6">
											<div class="text-muted">Cliente</div>
											<strong>
              Erasmo Buque	
            </strong>
											<p>
												Av. Eduardo Mondlhane N.2345 <br> Maputo Cidade <br> 834567000 <br> 
												<a href="#">
                erasmo.buque@gmail.com
              </a>
											</p>
										</div>
										<div class="col-md-6 text-md-end">
											<div class="text-muted">Esatado processo</div>
											<strong>
              Por alocar seccao
            </strong>
											<p>
											
										</div>
									</div>

									<table class="table table-sm">
										<thead>
											<tr>
												<th>Description</th>
												<th></th>
												<th class="text-end">Valor</th>
											</tr>
										</thead>
										<tbody>
											<tr>
										
											<tr>
												<td>Valor sem multa </td>
												<td> </td>
												<td class="text-end">25.00 MT</td>
											</tr>
										
											<tr>
												<th>&nbsp;</th>
												<th>Multa </th>
												<th class="text-end">100%</th>
											</tr>
											<tr>
												<th>&nbsp;</th>
												<th>Total </th>
												<th class="text-end">268.85 MT</th>
											</tr>
										</tbody>
									</table>

									<div class="text-left">
										
										<div class="btn-group">
											<button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Alocar seccao
              </button>
											
										</div>
            Alocar seccao
          </a>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			<?php require 'rodape.php'?>

		</div>
	</div>

	<script src="js/app.js"></script>

</body>

<?php


}else{
 echo "<script> location.href='index.php'; </script>";
}
?>

</html>