<?php


function Daywork($startDate, $endDate){

$workingDays = 0; 
$startTimestamp = strtotime($startDate);
$endTimestamp = strtotime($endDate);

 
for($i=$startTimestamp; $i<=$endTimestamp; $i = $i+(60*60*24) ){
if(date("N",$i) <= 5) $workingDays = $workingDays + 1;
}

return $workingDays;
}

function Seccoes($Con){
$Buscar = $Con->prepare("SELECT * FROM seccao");
$Buscar->execute();



return $Buscar;
	
}


function Processos($Con){
$Buscarpr = $Con->prepare("SELECT * FROM processos");
$Buscarpr->execute();


return $Buscarpr;
	
}

function Processospende($Con){
    $Buscarpr = $Con->prepare("SELECT * FROM processos WHERE estado='0'");
    $Buscarpr->execute();
    
    
    return $Buscarpr;
        
    }

function ProcessosPorSeccao($Con,$IDSection){
$Buscarpr = $Con->prepare("SELECT * FROM processos WHERE ID_Seccao=?");
$Buscarpr->bindParam(1, $IDSection);
$Buscarpr->execute();


return $Buscarpr;
	
}
?> 