<?php

require 'ConectDB/index.php';
require 'Config.php';
session_start();

if(isset($_SESSION['Tipo'])){
 $PageL2 = "";    
$Page = "RegistarProcessos"; 

$ID = $_SESSION["ID_USER"];


?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Processo | Registo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<?php require 'menu.php'?>

		<div class="main">
			<?php require 'header.php'?>;

			<main class="content">


			<div class="card">
				<form method="POST" id="RegistarProcesso">
					<div class="card-header">

						<h5 class="card-title mb-0">Dados do Queixoso</h5>
					</div>
					<div class="card-body">
						

						<div class="row">

								<div class="mb-3 col-md-6">
									<label class="form-label" for="inputCity">Nome</label>
									<input type="text" class="form-control" name="NomeQueixoso" placeholder="Nome" required>
								</div>
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Email</label>
									<input type="text" class="form-control" name="EmailQueixoso" placeholder="Email" required>
									
								</div>
								<div class="mb-3 col-md-2">
									<label class="form-label" for="inputZip">Telefone</label>
									<input type="text" class="form-control" name="TelefoneQueixoso" placeholder="Telefone" required>
								</div>
						</div>

						<div class="row">

							<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Tipo de Documento</label>
									<select class="form-control" name="TipoDocumentoIdentificacaoQueixoso" required>
										<option>Selecione</option>
										<option value="">Selecione</option>
										<option value="Cedula">Cedula</option>										
										<option value="BI">BI</option>
										<option value="Dir">Dir</option>
										<option value="Carta de Condução">Carta de Condução</option>
										<option value="Passaporte">Passaporte</option>

									</select>
								</div>
							
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Numero do Ducumento</label>
									<input type="text" class="form-control" name="NumeroDocumentoQueixoso" required>
								</div>
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Local de Emissão</label>
									<input type="text" class="form-control" name="LocalDeEmissaoDocumentoQueixoso" required>
									
								</div>

							</div>

							
							<div class="mb-3">
								<label class="form-label" for="inputAddress2">Endereço</label>
								<input type="text" class="form-control" name="EnredecoQueixoso"  placeholder="Endereço" required>
							</div>
							
						

					</div>
				</div>


				<div class="card">
					<div class="card-header">

						<h5 class="card-title mb-0">Dados Culposo(opcional)</h5>
					</div>
					<div class="card-body">
						<input type="hidden" name="ID" value="<?php echo $ID?>">
						

						<div class="row">

								<div class="mb-3 col-md-6">
									<label class="form-label" for="inputCity">Nome</label>
									<input type="text" class="form-control" name="NomeCulposos" placeholder="Nome" required>
								</div>
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Email</label>
									<input type="text" class="form-control" name="EmailCulposo" placeholder="Email" required>
									
								</div>
								<div class="mb-3 col-md-2">
									<label class="form-label" for="inputZip">Telefone</label>
									<input type="text" class="form-control" name="TelefoneCulposo" placeholder="Telefone" required>
								</div>
						</div>

						<div class="row">

							<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Tipo de Documento</label>
									<select class="form-control" name="TipoDocumentoCulposos" required>
										<option>Selecione</option>
										<option value="">Selecione</option>
										<option value="Cedula">Cedula</option>										
										<option value="BI">BI</option>
										<option value="Dir">Dir</option>
										<option value="Carta de Condução">Carta de Condução</option>
										<option value="Passaporte">Passaporte</option>

									</select>
								</div>
							
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Numero do Ducumento</label>
									<input type="text" class="form-control" name="NumeroDocumentoCulposos" required>
								</div>
								<div class="mb-3 col-md-4">
									<label class="form-label" for="inputCity">Local de Emissão</label>
									<input type="text" class="form-control" name="LocalDeEmissaoCulposo" required>
									
								</div>

							</div>

							
							<div class="mb-3">
								<label class="form-label" for="inputAddress2">Endereço</label>
								<input type="text" class="form-control" name="EnderecoCulposos"  placeholder="Endereço" required>
							</div>
							
						

					</div>
				</div>

				<div class="card">
										<div class="card-header">

											<h5 class="card-title mb-0">Dados do processo</h5>
										</div>
										<div class="card-body">
											
										<div class="row">
								<div class="mb-3 col-md-6">
									<label class="form-label" for="inputCity">Origem do processo</label>
									<select class="form-control" name="OrigemProcess" required>
										<option value="">Selecione</option>
										<option value="Directo">Directo</option>										
										<option value="Esquadra">Esquadra</option>
									</select>
								</div>

								</div>
								<div class="row">
								<div class="mb-3 col-md-6	">
									<label class="form-label" for="inputCity">Tipo</label>
									<select class="form-control" name="TipoProcesso" required>
										<option value="">Selecione</option>
										<option value="Crime">Crime</option>
										<option value="Divórcio">Divórcio</option>
									</select>
									
								</div>

								<div class="mb-3 col-md-6	">
									<label class="form-label" for="inputCity">Secção</label>
									<select class="form-control" name="Seccao" required>
										<option value="">Selecione</option>

										<?php

										$ArraySecccoes = Seccoes($Connection);

										while($C = $ArraySecccoes->fetch(PDO::FETCH_OBJ)){

											echo "<option value='$C->ID_Seccao'>$C->Nome_Seccao</option>";
										}

										?>
										
										
									</select>
									
								</div>
							</div>

												
												
												
												<button id="GravarProcesso" class="btn btn-primary">Abrir Processo</button> 
											</form>

										</div>
									</div>

			</main>

			<?php require 'rodape.php'?>
		</div>
	</div>
      
	<script src="js/app.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="js/verity.js"></script>
    

</body>
<?php


}else{
 echo "<script> location.href='index.php'; </script>";
}
?>
</html>