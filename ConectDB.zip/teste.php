<?php
    
 
	echo abs( crc32( uniqid() ) ); 
?>