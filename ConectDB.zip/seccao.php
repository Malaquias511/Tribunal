<?php

require 'ConectDB/index.php';
require 'Config.php';
session_start();

if(isset($_SESSION['Tipo'])){
$PageL2 = "";  
$Page = "Seccao";



?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Seccao</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
	<link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet">
	<link href="https://cdn.datatables.net/1.10.24/css/dataTables.jqueryui.min.css" rel="stylesheet">
	<link href="https://cdn.datatables.net/fixedcolumns/3.3.2/css/fixedColumns.jqueryui.min.css" rel="stylesheet">



</head>

<body>
	<div class="wrapper">
<?php require 'menu.php'?>


		<div class="main">
			<?php require 'header.php'?>;


			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Listas de processos por secção</h1>

					<div class="row">
						<div class="col-md-3 col-xl-2">

							<div class="card">
								<div class="card-header">
									<h5 class="card-title mb-0">Processos</h5>
								</div>

								<div class="list-group list-group-flush" role="tablist">
									<?php

									$Seccoes =Seccoes($Connection);
									$Count =0;

									while($C = $Seccoes->fetch(PDO::FETCH_OBJ)){

										if($Count < 1){

											echo "<a class='list-group-item list-group-item-action active' data-bs-toggle='list' href='#secca$C->ID_Seccao' role='tab'>
													$C->Nome_Seccao
										        </a>";

										}else{

											echo "<a class='list-group-item list-group-item-action' data-bs-toggle='list' href='#secca$C->ID_Seccao' role='tab'>
													$C->Nome_Seccao
										        </a>";

										}

										$Count +=1;

										

									}


									?>
								</div>
							</div>
						</div>

						<div class="col-md-9 col-xl-10">
							<div class="tab-content">



								<?php

								$Seccoes1 =Seccoes($Connection);
								$Contador =0;

								while($C = $Seccoes1->fetch(PDO::FETCH_OBJ)){

									if($Contador < 1){

										echo "<div class='tab-pane fade show active' id='secca$C->ID_Seccao' role='tabpanel'>";

									}else{

										echo "<div class='tab-pane fade' id='secca$C->ID_Seccao' role='tabpanel'>";

									}

									$Contador +=1;


								?>

								
						
								
								
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Processos da Secção <b><?php echo $C->Nome_Seccao ?></b></h5>

											<!-- seccao 2-->

											<table class="display nowrap example" style="width:100%">
												<thead>
													<tr>
														<th>Queixoso</th>
														<th class="d-none d-xl-table-cell">Culposo</th>
														<th class="d-none d-xl-table-cell">Nº Processo</th>
														<th class="d-none d-xl-table-cell">Data de Entrada</th>
														<th>Estado</th>
														<th class="d-none d-md-table-cell">Valor a Pagar</th>
													</tr>
												</thead>
												<tbody>

													<?php   
                                                        $Processos = ProcessosPorSeccao($Connection, $C->ID_Seccao);
                                                        $NomeQuixoso;
                                                      

                                                        while($C = $Processos->fetch(PDO::FETCH_OBJ)){

                                                        	$ArrayQueixoso = json_decode($C->Quixoso, true);
                                                        	$ArrayCulposo = json_decode($C->Culposo, true);



                                                        	?>

													<tr>
														<td><?php echo $ArrayQueixoso["Nome"]?></td>
														<td class="d-none d-xl-table-cell"><?php echo $ArrayCulposo["Nome"]?></td>
														<td><span class="badge bg-primary"><?php echo $C->Numero ?></span></td>
														<td class="d-none d-xl-table-cell"><?php echo $C->Data_Criacao ?></td>
														
														<td class="d-none d-md-table-cell">Pendente</td>
														<td class="">0,00 MZN</td>
													</tr>
													<?php

												}

													?>
													
												</tbody>
											</table>





										</div>
									</div>
								</div>

								<?php

							}



								?>





								<div class="tab-pane fade" id="secca1" role="tabpanel">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Secção 1</h5>

											<!-- seccao 2-->

										</div>
									</div>
								</div>

								
								
							</div>
						</div>
					</div>

				</div>
			</main>

		
		</div>
	</div>

	<script src="js/app.js"></script>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/dataTables.jqueryui.min.js"></script>
	<script src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>
	


	<script>
    $(document).ready(function() {
    var table = $('.example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         false,
        fixedColumns:   true
    } );
 
    new $.fn.dataTable.FixedColumns( table );
} );
</script>

</body>


<?php


}else{
 echo "<script> location.href='index.php'; </script>";
}
?>

</html>