<?php

require 'ConectDB/index.php';
require 'Config.php';
session_start();

if(isset($_SESSION['Tipo'])){
$PageL2 = "TodosProcessos";  
$Page = "Processos";



?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<title>Seccao</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
	<link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet">
	<link href="https://cdn.datatables.net/1.10.24/css/dataTables.jqueryui.min.css" rel="stylesheet">
	<link href="https://cdn.datatables.net/fixedcolumns/3.3.2/css/fixedColumns.jqueryui.min.css" rel="stylesheet">



</head>

<body>
	<div class="wrapper">
<?php require 'menu.php'?>


		<div class="main">
			<?php require 'header.php'?>;


			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Lista de Todos os Processos</h1>

					<div class="row">
						

						<div class="col-md-12 col-xl-12 ">
							<div class="tab-content">
								<div class="tab-pane fade show active" id="secca1" role="tabpanel">

									<div class="card">
										<div class="card-header">

											<h5 class="card-title mb-0"></h5>
										</div>
										<div class="card-body">
											<!--  corpo seccao1  -->
											<table id="example" class="display nowrap table table-hover my-0" style="width:100%">
												<thead>
													<tr>
														<th>Nome do Arguido</th>
														<th class="d-none d-xl-table-cell">Data Registo</th>
														<th class="d-none d-xl-table-cell">Processo</th>
														<th>Estado</th>
														<th class="d-none d-md-table-cell">Fucionario</th>
													</tr>
												</thead>

                                               
                                                    
                                                


												<tbody>
												
                                                
                                                    

                                                        <?php   
                                                        $Processos = Processos($Connection);
                                                        $NomeQuixoso;
                                                      

                                                        while($C = $Processos->fetch(PDO::FETCH_OBJ)){

                                                        $ArrayQueixoso = json_decode($C->Quixoso, true);
                                                        $NomeQuixoso = $ArrayQueixoso["Nome"];                                             	


                                                        	


 															echo "<tr>";
                                                        	echo "<td>$NomeQuixoso</td>";
                                                        	echo "<td>$C->Data_Criacao</td>";
                                                        	echo "<td>$C->Numero</td>";
                                                        	if ($C->Estado <= 1) {
                                                        		echo "<td>Pedente</td>";
                                                        	}else{
                                                        		echo "<td>Fechado</td>";
                                                        	}
                                                        	
                                                        	echo "<td>$C->Data_Criacao</td>";
                                                        	echo "</tr>";

                                                        }
                                                        ?>
                                                    									
												</tbody>
											</table>



										</div>
									</div>


								</div>
								
								<div class="tab-pane fade" id="secca2" role="tabpanel">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Secção 2</h5>

											<!-- seccao 2-->

										</div>
									</div>
								</div>

								<div class="tab-pane fade" id="secca3" role="tabpanel">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Secção 3</h5>

											<!-- seccao 2-->

										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="secca4" role="tabpanel">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Secção 4</h5>

											<!-- seccao 2-->

										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="secca5" role="tabpanel">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Secção 5</h5>

											<!-- seccao 2-->

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

		
		</div>
	</div>

	<script src="js/app.js"></script>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.24/js/dataTables.jqueryui.min.js"></script>
	<script src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>
	


	<script>
    $(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         false,
        fixedColumns:   true
    } );
 
    new $.fn.dataTable.FixedColumns( table );
} );
</script>

</body>


<?php


}else{
 echo "<script> location.href='index.php'; </script>";
}
?>

</html>