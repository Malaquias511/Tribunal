	<nav id="sidebar" class="sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="dash.php">
          <span class="align-middle">Admin Processos</span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<?php

					if($Page === "Dashboard"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>

					
						<a class="sidebar-link" href="dash.php">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>

					<?php

					if($Page === "RegistarProcessos"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>
						<a class="sidebar-link" href="registar.php">
			  <i class="align-middle" data-feather="file-plus"></i> <span class="align-middle">Registar Processo</span>

            </a>
					</li>

					<?php

					if($Page === "Processos"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>
						<a href="#auth" data-bs-toggle="collapse" class="sidebar-link collapsed">
              <i class="align-middle" data-feather="list"></i> <span class="align-middle">Processos</span>
            </a>
						<ul id="auth" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
							<?php

					if($PageL2 === "TodosProcessos"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>

								<a class="sidebar-link" href="tabela_todas.php">Todos</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="tabela_alocar.php">Sem secção</a></li>
							
						</ul>
					</li>




					<?php

					if($Page === "Seccao"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>
						<a class="sidebar-link" href="seccao.php">
              <i class="align-middle" data-feather="package"></i> <span class="align-middle">Secção</span>
            </a>
					</li>

		
				

					<?php

					if($Page === "Usuario"){

						echo '<li class="sidebar-item active">';

					}else{

						echo '<li class="sidebar-item">';

					}

					?>
						Opcoes de usuario
					</li>
					<li class="sidebar-item">
						<a href="#outros" data-bs-toggle="collapse" class="sidebar-link collapsed">
              <i class="align-middle" data-feather="users"></i> <span class="align-middle">Usuario</span>
            </a>
						<ul id="outros" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
							<li class="sidebar-item"><a class="sidebar-link" href="#">Perfil</a></li>
							<li class="sidebar-item"><a class="sidebar-link" href="#">Mudar palavra-passe</a></li>
						</ul>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="sair.php">
              <i class="align-middle" data-feather="log-out"></i> <span class="align-middle">sair</span>
            </a>
					</li>


					
					
				</ul>

				
			</div>
		</nav>