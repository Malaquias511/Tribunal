$(document).ready(function(){
                
$("#Entrar").click(function(){
 document.getElementById("Entrar").disabled = true; 

 $.ajax({
                        
url:"login.php",
type:"post",
data:$("#Login").serialize(),
success:function(d){
                            
var Dados = JSON.parse(d);
                  
if(Dados[0].CodeStatos !=0){

  Swal.fire({
position: 'top-end',
icon: Dados[0].Type,
text:Dados[0].Mensagem,
title: Dados[0].Titulo,
showConfirmButton: false,
timer: 6000
});

  setTimeout(function(){
 window.location.href = "dash.php";
 }, 3500);

}else{

  Swal.fire({
position: 'top-end',
icon: Dados[0].Type,
text:Dados[0].Mensagem,
title: Dados[0].Titulo,
showConfirmButton: false,
timer: 6000
});
 document.getElementById("Entrar").disabled = false; 
$("#Login").trigger("reset");

}


}
});   
         
});





$("#GravarProcesso").click(function(event){
if($("#RegistarProcesso").valid()){ 
   document.getElementById("GravarProcesso").disabled = true; 
 $.ajax({
                        
url:"GravarPeocesso.php",
type:"post",
data:$("#RegistarProcesso").serialize(),
success:function(d){
                            
var Dados = JSON.parse(d);


Swal.fire({
position: 'top-end',
icon: Dados[0].Type,
text:Dados[0].Mensagem,
title: Dados[0].Titulo,
showConfirmButton: false,
timer: 6000
});

 document.getElementById("GravarProcesso").disabled = false; 

 if(Dados[0].CodeStatos !=0){
$("#RegistarProcesso").trigger("reset");
}
}
});  

}else{

  return
} 
         
});


});


