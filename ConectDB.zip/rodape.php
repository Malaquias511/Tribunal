<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a href="#" class="text-muted"><strong>Gestao de processos</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="#">Supporte</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Centro de ajuda</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Privacidade</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#">Termos</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>