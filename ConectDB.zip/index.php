



<html lang="en">
   <head>
      <meta charset="euc-jp">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
      <meta name="author" content="AdminKit">
      <meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="shortcut icon" href="img/icons/icon-48x48.png" />
      <title>Autenticacao</title>
      <link href="css/app.css" rel="stylesheet">
   </head>
   <body>
      <main class="d-flex w-100">
         <div class="container d-flex flex-column">
            <div class="row vh-100">
               <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                  <div class="d-table-cell align-middle">
                     <div class="text-center mt-4">
                        <h1 class="h2">Damos-lhe as boas-vindas</h1>
                        <p class="lead"> Inicie sessão </p>
                     </div>
                     <div class="card">
                        <div class="card-body">
                           <div class="m-sm-4">
                              <div class="text-center"> <img src="img/avatars/avatar.jpg" alt="Charles Hall" class="img-fluid rounded-circle" width="132" height="132" /> </div>
                              <form method="POST" id="Login">
                                 <div class="mb-3"> <label class="form-label">Nome de usuario</label> <input class="form-control form-control-lg" type="email" name="email" placeholder="introduza o nome de usuario " required /> </div>
                                 <div class="mb-3"> <label class="form-label">palavra-passe</label> <input class="form-control form-control-lg" type="password" name="password" placeholder="introduza a palavra-passe" required /> <small> <a href="pages-reset-password.html">Esqueceu-se da palavra-passe?</a> </small> </div>
                                 <div> <label class="form-check"> <input class="form-check-input" type="checkbox" value="remember-me" name="remember-me" checked> <span class="form-check-label"> Mostrar palavra-passe </span> </label> </div>
                                 <div class="text-center mt-3">
                                    <button class="btn btn-lg btn-primary" id="Entrar">Entrar</button> <!-- <button type="submit" class="btn btn-lg btn-primary">Sign in</button> --> 
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </main>
      <script src="js/app.js"></script> 
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="js/verity.js"></script>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   </body>
</html>